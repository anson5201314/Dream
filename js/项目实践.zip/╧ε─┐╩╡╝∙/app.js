const express=require('express');
//引入路由对象
const userRouter=require('./router/user.js');
//引入第三方body-parser中间件
const bodyParser=require('body-parser');
//创建服务器为并设置端口
var app=express();
app.listen(8080);
//使用body-parser中间件,将post请求的数据解析为对象
app.use(bodyParser.urlencoded({
	extended:false
}));
//使用静态资源挂载到public目录下
	app.use(express.static('./public'))
	//挂载到/user下  /user/reg
	app.use('/user',userRouter);